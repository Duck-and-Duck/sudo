# Sudoku-AGI report (v6.0.0)

* device `cuda` | params **533,032** | iters **381** | wall **38.7m** | peak GPU **2239 MiB**

## 1. Acceptance gate

**PASS** - `pass_at_2` >= 0.95 on tiers <= 2: **1.0000**

## 2. Proof suite (P1-P14)
| id | claim | status | measurement |
|---|---|---|---|
| P4 | constraint graph + 5 relation types | **PASS** | 20 peers/cell, REL symmetric, type counts=[81, 972, 324, 324, 4860] |
| P1 | verifier soundness + completeness | **PASS** | 212/212 value swaps rejected; 2 verifiers agree |
| P2 | solver == independent reference | **PASS** | 12 boards bitmask+MRV vs naive set match |
| P3 | generator: unique + valid + deterministic | **PASS** | 24 puzzles UNIQUE; 0.5s |
| P10 | information accounting | **PASS** | log2(#grids)=72.50 bits/grid; |G|=1,218,998,108,160 |
| P5 | exact G-equivariance of HyperGraphNet | **PASS** | max|f(gx)-g f(x)| logits=2.98e-07 cand=3.58e-07 value=7.45e-08 |
| P6 | P(illegal action) == 0 exactly | **PASS** | 35 env steps: 0 illegal picks |
| P7 | numerical range certificate | **PASS** | all finite T=16; max|logit|=0.646 <= 17.740 |
| P8 | Muon trust region (spectral) | **PASS** | cert=1.2048; sigma_max=1.2022 |
| P11 | potential shaping is policy-invariant | **PASS** | max err = 0.00e+00 |
| P12 | pass@k estimator unbiased | **PASS** | exact hypergeometric 1 - C(n-c,k)/C(n,k) |
| P13 | RLOO baseline unbiased | **PASS** | G/(G-1) exact leave-one-out unbiasedness |
| P9 | resource accounting (toy net) | **PASS** | toy P=42,204 => 0.16 MiB weights |
| P14 | no train/test leakage | **PASS** | 0/800 test grids appear in train |

## 3. Held-out results
| tier | n | clues | FullBoard Sys1 | PTRM(16) | Step Greedy | pass@2 | Sys1+2 | sims | ECE |
|---|---|---|---|---|---|---|---|---|---|
| T1 easy | 24 | 40.8 | 1.000 | **1.000** | 1.000 | 1.000 | **1.000** | 0.0 | 0.000 |
| T2 medium | 24 | 30.6 | 1.000 | **1.000** | 1.000 | 1.000 | **1.000** | 0.0 | 0.000 |
| T3 hard | 24 | 29.6 | 0.875 | **0.875** | 1.000 | 0.792 | **1.000** | 0.1 | 0.009 |
| T4 expert | 24 | 26.2 | 0.917 | **0.917** | 0.750 | 0.667 | **0.958** | 2.8 | 0.088 |
| T5 extreme | 24 | 25.4 | 0.833 | **0.833** | 0.875 | 0.708 | **1.000** | 2.2 | 0.054 |

## 4. Memorisation control
| tier | train | test | gap |
|---|---|---|---|
| T1 easy | 1.000 | 1.000 | +0.000 |
| T2 medium | 1.000 | 1.000 | +0.000 |
| T3 hard | 0.875 | 1.000 | -0.125 |
| T4 expert | 1.000 | 0.750 | +0.250 |
| T5 extreme | 0.750 | 0.875 | -0.125 |

## 5. Gameplay Video
* `['runs\\sudoku_v6\\play_sudoku.gif', 'runs\\sudoku_v6\\play_sudoku_storyboard.png']`