# Sokoban-AGI report (v1.1.0)

* device `cuda` | grid `8x8` | params **531,940** | iters **353** | peak GPU **4305 MiB**

## 1. Proof Suite (P1-P14)

| id | claim | status | measurement |
|---|---|---|---|
| P4 | D4 hypergraph topology (row/col/3x3) | **PASS** | 8x8=64 cells, row/col=(8,8), patch=(64,9) |
| P1 | verifier soundness + box conservation | **PASS** | 6 optimal trajectories verified end-to-end |
| P3 | generator: solvable + deterministic | **PASS** | all levels BFS-verified solvable; seed replay identical |
| P2 | BFS+pruning == unpruned reference | **PASS** | 5 levels exact shortest-path match |
| P10 | information & D4 symmetry accounting | **PASS** | |D4|=8 dihedral symmetries; walkable~36 cells => C(36,4)*36 > 1e6 states/map |
| P5 | exact D4 equivariance (all 8 symms) | **PASS** | max|f(gx)-g f(x)| logits=6.11e-07 value=5.96e-08 |
| P6 | P(illegal move) == 0 exactly | **PASS** | 30 env steps: 0 wall/box-jam illegal picks |
| P7 | numerical range certificate (T=16) | **PASS** | all finite; max|logit|=0.443 <= bound 20.337 |
| P8 | Muon trust region (spectral) | **PASS** | cert=1.2048; sigma_max=1.2022; sigma_min=0.682 |
| P11 | potential shaping is policy-invariant | **PASS** | max|sum_t F_t - (-Phi(s0))| = 0.00e+00 |
| P12 | pass@k estimator unbiased | **PASS** | exact hypergeometric 1 - C(n-c,k)/C(n,k) |
| P13 | RLOO baseline unbiased | **PASS** | G/(G-1) leave-one-out unbiasedness inherited from core |
| P9 | resource accounting (toy net) | **PASS** | toy P=41,828 => 0.16 MiB weights |
| P14 | no D4-orbit train/test leakage | **PASS** | 0/192 test levels overlap train D4 orbits |

## 2. Held-Out Sokoban Results (disjoint D4-canonical levels)

| tier | n | opt_steps | Sys1 greedy | pass@1 | pass@2 | Sys1+2 (`simulate`) | Sys2 nodes | Blind BFS nodes |
|---|---|---|---|---|---|---|---|---|
| T1 easy(1b) | 48 | 6.2 | 0.812 | 0.948 | 0.976 | **1.000** | 1.8 | 65 |
| T2 med(2b) | 48 | 9.8 | 0.521 | 0.703 | 0.806 | **1.000** | 9.8 | 432 |
| T3 hard(3b) | 48 | 12.6 | 0.375 | 0.599 | 0.785 | **0.979** | 17.6 | 2246 |
| T4 expert(4b) | 48 | 16.8 | 0.062 | 0.229 | 0.326 | **0.479** | 49.8 | 7617 |

## 3. Zero-Shot Size Transfer (Trained 8x8 -> Tested 10x10, 0 extra training)

| tier | n | opt_steps | Sys1 greedy | pass@2 | Sys1+2 | avg nodes |
|---|---|---|---|---|---|---|
| T1 easy(1b) | 24 | 6.2 | 0.958 | 1.000 | **1.000** | 0.5 |
| T2 med(2b) | 24 | 9.6 | 0.667 | 0.958 | **1.000** | 6.0 |
| T3 hard(3b) | 24 | 13.0 | 0.250 | 0.833 | **0.917** | 19.5 |
| T4 expert(4b) | 24 | 16.3 | 0.333 | 0.583 | **0.708** | 32.2 |

## 4. Memorisation Control (TRAIN vs TEST)
| tier | train | test | gap |
|---|---|---|---|
| T1 easy(1b) | 0.917 | 0.812 | +0.104 |
| T2 med(2b) | 0.625 | 0.521 | +0.104 |
| T3 hard(3b) | 0.208 | 0.375 | -0.167 |
| T4 expert(4b) | 0.083 | 0.062 | +0.021 |

## 5. Recurrence-Depth Ablation (T3-T4)
| T steps | Sys1 greedy |
|---|---|
| 1 | 0.312 |
| 2 | 0.250 |
| 4 | 0.208 |
| 8 | 0.083 |
| 12 | 0.083 |

## 6. Featured Gameplay Videos
* Rendered: `['runs\\soko_full\\play_sys1_pass1.gif', 'runs\\soko_full\\play_sys2.gif']`