# Sokoban-AGI report (v1.2.0)

* device `cuda` | grid `10x10` | params **531,940** | iters **479** | peak GPU **3375 MiB**

## 1. Proof Suite (P1-P14)

| id | claim | status | measurement |
|---|---|---|---|
| P4 | D4 hypergraph topology (row/col/3x3) | **PASS** | 10x10=100 cells, row/col=(10,10), patch=(100,9) |
| P1 | verifier soundness + box conservation | **PASS** | 5 optimal trajectories verified end-to-end |
| P3 | generator: solvable + deterministic | **PASS** | all levels BFS-verified solvable; seed replay identical |
| P2 | BFS == A* == unpruned reference | **PASS** | 5 levels exact shortest-path match |
| P10 | information & D4 symmetry accounting | **PASS** | |D4|=8 dihedral symmetries; walkable~64 cells => C(64,4)*64 > 1e6 states/map |
| P5 | exact D4 equivariance (all 8 symms) | **PASS** | max|f(gx)-g f(x)| logits=4.32e-07 value=8.94e-08 |
| P6 | P(illegal move) == 0 exactly | **PASS** | 30 env steps: 0 wall/box-jam illegal picks |
| P7 | numerical range certificate (T=16) | **PASS** | all finite; max|logit|=0.427 <= bound 20.337 |
| P8 | Muon trust region (spectral) | **PASS** | cert=1.2048; sigma_max=1.2022; sigma_min=0.682 |
| P11 | potential shaping is policy-invariant | **PASS** | max|sum_t F_t - (-Phi(s0))| = 0.00e+00 |
| P12 | pass@k estimator unbiased | **PASS** | exact hypergeometric 1 - C(n-c,k)/C(n,k) |
| P13 | RLOO baseline unbiased | **PASS** | G/(G-1) leave-one-out unbiasedness inherited from core |
| P9 | resource accounting (toy net) | **PASS** | toy P=41,828 => 0.16 MiB weights |
| P14 | no D4-orbit train/test leakage | **PASS** | 0/64 test levels overlap train D4 orbits |

## 2. Held-Out Sokoban Results (disjoint D4-canonical levels)

| tier | n | opt_steps | Sys1 greedy | pass@1 | pass@2 | Sys1+2 (`simulate`) | Sys2 nodes | Blind BFS nodes |
|---|---|---|---|---|---|---|---|---|
| T1 easy(1b) | 16 | 6.9 | 0.625 | 0.906 | 0.979 | **1.000** | 6.4 | 145 |
| T2 med(2b) | 16 | 10.4 | 0.438 | 0.703 | 0.844 | **1.000** | 12.5 | 988 |
| T3 hard(3b) | 16 | 12.5 | 0.562 | 0.594 | 0.771 | **0.938** | 16.4 | 4127 |
| T4 expert(4b) | 16 | 19.3 | 0.312 | 0.312 | 0.479 | **0.625** | 35.2 | 9962 |

## 4. Memorisation Control (TRAIN vs TEST)
| tier | train | test | gap |
|---|---|---|---|
| T1 easy(1b) | 0.562 | 0.625 | -0.062 |
| T2 med(2b) | 0.500 | 0.438 | +0.062 |
| T3 hard(3b) | 0.438 | 0.562 | -0.125 |
| T4 expert(4b) | 0.125 | 0.312 | -0.188 |

## 5. Recurrence-Depth Ablation (T3-T4)
| T steps | Sys1 greedy |
|---|---|
| 1 | 0.469 |
| 2 | 0.375 |
| 4 | 0.438 |
| 8 | 0.312 |
| 12 | 0.219 |

## 6. Featured Gameplay Videos
* Rendered: `['runs\\boxoban_v1\\play_sys1_pass1.gif', 'runs\\boxoban_v1\\play_sys1_pass1_storyboard.png', 'runs\\boxoban_v1\\play_sys2.gif', 'runs\\boxoban_v1\\play_sys2_storyboard.png']`