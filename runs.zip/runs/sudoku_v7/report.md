# Sudoku-AGI report (v7.0.0)

* device `cuda` | params **709,589** | iters **437** | wall **39.2m** | peak GPU **2259 MiB**

## 1. Acceptance gate

**PASS** - `pass_at_2` >= 0.95 on tiers <= 2: **1.0000**

## 2. Proof suite (P1-P14)
| id | claim | status | measurement |
|---|---|---|---|
| P4 | constraint graph + 5 relation types | **PASS** | 20 peers/cell, REL symmetric |
| P1 | verifier soundness + completeness | **PASS** | 212/212 value swaps rejected |
| P2 | solver == independent reference | **PASS** | bitmask+MRV == naive set solver |
| P3 | generator: unique + deterministic | **PASS** | 24 puzzles UNIQUE |
| P10 | information accounting | **PASS** | log2(#grids)=72.50 bits/grid; |G|=1.219e12 |
| P5 | G-equivariance (reasoner + world model) | **PASS** | enc=2.98e-07 dyn=4.17e-07 val=5.96e-08 (8 random g in G) |
| P6 | P(illegal action) == 0 exactly | **PASS** | 35 env steps: 0 illegal picks |
| P7 | numerical range certificate | **PASS** | max|logit|=0.646 <= 17.740 |
| P8 | Muon trust region (spectral) | **PASS** | sigma_max=1.2022 |
| P11 | potential shaping invariant | **PASS** | telescoping sum = -Phi(s0) verified |
| P12 | pass@k estimator unbiased | **PASS** | exact hypergeometric 1 - C(n-c,k)/C(n,k) |
| P13 | RLOO baseline unbiased | **PASS** | G/(G-1) leave-one-out exact |
| P9 | resource accounting (toy net) | **PASS** | toy P=62,153 => 0.24 MiB weights |
| P14 | no train/test leakage | **PASS** | 0/800 test grids appear in train |

## 3. Held-out results
| tier | n | clues | FocusDiff(1) | PTRM(16) | WM-Tree(0-rules) | StepGreedy | pass@2 | Sys1+2 | ECE |
|---|---|---|---|---|---|---|---|---|---|
| T1 easy | 24 | 40.8 | 1.000 | **1.000** | **1.000** | 1.000 | 1.000 | **1.000** | 0.000 |
| T2 medium | 24 | 30.6 | 1.000 | **1.000** | **1.000** | 1.000 | 1.000 | **1.000** | 0.001 |
| T3 hard | 24 | 29.6 | 0.917 | **0.958** | **0.917** | 0.958 | 0.750 | **1.000** | 0.018 |
| T4 expert | 24 | 26.2 | 0.958 | **0.958** | **0.917** | 0.917 | 0.875 | **0.958** | 0.041 |
| T5 extreme | 24 | 25.4 | 0.833 | **0.958** | **0.875** | 0.917 | 0.875 | **1.000** | 0.026 |

## 4. Memorisation control
| tier | train | test | gap |
|---|---|---|---|
| T1 easy | 1.000 | 1.000 | +0.000 |
| T2 medium | 1.000 | 1.000 | +0.000 |
| T3 hard | 1.000 | 0.958 | +0.042 |
| T4 expert | 0.875 | 0.917 | -0.042 |
| T5 extreme | 0.625 | 0.917 | -0.292 |