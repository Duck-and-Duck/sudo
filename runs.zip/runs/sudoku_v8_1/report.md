# Sudoku-AGI report (v8.1.0 - Raw-Obs + World Model + Level Engine)

* device `cuda` | params **755,478** | iters **170** | wall **34.3m** | peak GPU **3431 MiB**

## 1. Acceptance gate

**PASS** - `pass_at_2` >= 0.95 on tiers <= 2: **1.0000**

## 2. Proof suite (P1-P14)
| id | claim | status | measurement |
|---|---|---|---|
| P4 | constraint graph + 5 relation types | **PASS** | 20 peers/cell, REL symmetric |
| P1 | verifier soundness + multi-sol check | **PASS** | 212/212 swaps rejected |
| P2 | solver == independent reference | **PASS** | bitmask+MRV == naive set solver |
| P3 | generator: unique + deterministic | **PASS** | 24 puzzles UNIQUE |
| P10 | information accounting | **PASS** | log2(#grids)=72.50 bits/grid; |G|=1.219e12 |
| P5 | G-equivariance (raw-obs + world model) | **PASS** | enc=5.36e-07 dyn=5.66e-07 val=1.34e-07 |
| P6 | P(illegal action) == 0 exactly | **PASS** | 36 env steps: 0 illegal picks |
| P7 | numerical range certificate | **PASS** | max|logit|=0.938 <= 17.895 |
| P8 | Muon trust region (spectral) | **PASS** | sigma_max=1.2022 |
| P11 | potential shaping invariant | **PASS** | telescoping sum = -Phi(s0) |
| P12 | pass@k estimator unbiased | **PASS** | exact hypergeometric |
| P13 | RLOO baseline unbiased | **PASS** | G/(G-1) leave-one-out exact |
| P9 | resource accounting (raw-obs net) | **PASS** | toy P=67,210 => 0.26 MiB weights |
| P14 | no train/test leakage | **PASS** | 0/800 test grids appear in train |

## 3. Unique-Puzzle Held-Out Results (Raw-Obs, 0 rule crutches)
| tier | n | clues | FocusDiff(1) | PTRM(16) | WM-Tree(0-rules) | StepGreedy | pass@2 | Sys1+2 |
|---|---|---|---|---|---|---|---|---|
| T1 easy | 24 | 40.8 | 1.000 | **1.000** | **1.000** | 1.000 | 1.000 | **1.000** |
| T2 medium | 24 | 30.6 | 0.958 | **1.000** | **1.000** | 1.000 | 1.000 | **1.000** |
| T3 hard | 24 | 29.6 | 0.875 | **0.958** | **0.875** | 0.875 | 0.792 | **1.000** |
| T4 expert | 24 | 26.2 | 0.833 | **0.917** | **0.917** | 0.875 | 0.875 | **1.000** |
| T5 extreme | 24 | 25.4 | 0.833 | **1.000** | **0.667** | 0.667 | 0.708 | **0.958** |

## 4. Multi-Solution Leveled Puzzle Engine (Any Valid Completion Verified)
| level | n | FocusDiff(1) | PTRM(16) | WM-Tree |
|---|---|---|---|---|
| L1 trivial (70-79c) | 12 | 1.000 | **1.000** | **1.000** |
| L2 easy    (48-60c) | 12 | 1.000 | **1.000** | **1.000** |
| L3 medium  (32-44c) | 12 | 0.917 | **1.000** | **1.000** |
| L4 hard    (20-30c) | 12 | 0.917 | **1.000** | **1.000** |
| L5 open    (10-17c) | 12 | 0.000 | **1.000** | **0.750** |

## 5. Easiest Unique Puzzle Imagination (78 clues, true digit=9)
| digit | legal | policy p | V_imag | Dead_imag | latent_cos |
|---|---|---|---|---|---|
| 1 | False | 0.000 | 0.406 | 0.602 | 0.916 |
| 2 | False | 0.000 | 0.405 | 0.602 | 0.917 |
| 3 | False | 0.000 | 0.416 | 0.597 | 0.918 |
| 4 | False | 0.000 | 0.405 | 0.603 | 0.915 |
| 5 | False | 0.000 | 0.405 | 0.602 | 0.916 |
| 6 | False | 0.000 | 0.406 | 0.602 | 0.916 |
| 7 | False | 0.000 | 0.406 | 0.602 | 0.918 |
| 8 | False | 0.000 | 0.405 | 0.602 | 0.917 |
| 9 | True | 0.999 | 0.670 | 0.370 | 0.919 |

## 6. Memorisation control
| tier | train | test | gap |
|---|---|---|---|
| T1 easy | 1.000 | 1.000 | +0.000 |
| T2 medium | 0.938 | 1.000 | -0.062 |
| T3 hard | 0.938 | 0.875 | +0.062 |
| T4 expert | 0.875 | 0.875 | +0.000 |
| T5 extreme | 0.562 | 0.667 | -0.104 |