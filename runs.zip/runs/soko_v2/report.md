# Sokoban-AGI report (v1.1.2)

* device `cuda` | grid `8x8` | params **531,940** | iters **165** | peak GPU **4309 MiB**

## 1. Proof Suite (P1-P14)

| id | claim | status | measurement |
|---|---|---|---|
| P4 | D4 hypergraph topology (row/col/3x3) | **PASS** | 8x8=64 cells, row/col=(8,8), patch=(64,9) |
| P1 | verifier soundness + box conservation | **PASS** | 6 optimal trajectories verified end-to-end |
| P3 | generator: solvable + deterministic | **PASS** | all levels BFS-verified solvable; seed replay identical |
| P2 | BFS+pruning == unpruned reference | **PASS** | 5 levels exact shortest-path match |
| P10 | information & D4 symmetry accounting | **PASS** | |D4|=8 dihedral symmetries; walkable~36 cells => C(36,4)*36 > 1e6 states/map |
| P5 | exact D4 equivariance (all 8 symms) | **PASS** | max|f(gx)-g f(x)| logits=6.11e-07 value=5.96e-08 |
| P6 | P(illegal move) == 0 exactly | **PASS** | 30 env steps: 0 wall/box-jam illegal picks |
| P7 | numerical range certificate (T=16) | **PASS** | all finite; max|logit|=0.443 <= bound 20.337 |
| P8 | Muon trust region (spectral) | **PASS** | cert=1.2048; sigma_max=1.2022; sigma_min=0.682 |
| P11 | potential shaping is policy-invariant | **PASS** | max|sum_t F_t - (-Phi(s0))| = 0.00e+00 |
| P12 | pass@k estimator unbiased | **PASS** | exact hypergeometric 1 - C(n-c,k)/C(n,k) |
| P13 | RLOO baseline unbiased | **PASS** | G/(G-1) leave-one-out unbiasedness inherited from core |
| P9 | resource accounting (toy net) | **PASS** | toy P=41,828 => 0.16 MiB weights |
| P14 | no D4-orbit train/test leakage | **PASS** | 0/192 test levels overlap train D4 orbits |

## 2. Held-Out Sokoban Results (disjoint D4-canonical levels)

| tier | n | opt_steps | Sys1 greedy | pass@1 | pass@2 | Sys1+2 (`simulate`) | Sys2 nodes | Blind BFS nodes |
|---|---|---|---|---|---|---|---|---|
| T1 easy(1b) | 48 | 6.2 | 0.896 | 0.927 | 0.990 | **1.000** | 1.0 | 65 |
| T2 med(2b) | 48 | 9.8 | 0.500 | 0.688 | 0.767 | **0.958** | 11.4 | 432 |
| T3 hard(3b) | 48 | 12.6 | 0.438 | 0.599 | 0.670 | **0.917** | 17.9 | 2246 |
| T4 expert(4b) | 48 | 16.8 | 0.125 | 0.271 | 0.417 | **0.625** | 42.9 | 7617 |

## 3. Zero-Shot Size Transfer (Trained 8x8 -> Tested 10x10, 0 extra training)

| tier | n | opt_steps | Sys1 greedy | pass@2 | Sys1+2 | avg nodes |
|---|---|---|---|---|---|---|
| T1 easy(1b) | 24 | 6.2 | 0.875 | 1.000 | **1.000** | 1.2 |
| T2 med(2b) | 24 | 9.6 | 0.625 | 0.917 | **1.000** | 5.2 |
| T3 hard(3b) | 24 | 13.0 | 0.417 | 0.792 | **1.000** | 15.9 |
| T4 expert(4b) | 24 | 16.3 | 0.167 | 0.667 | **0.917** | 29.3 |

## 4. Memorisation Control (TRAIN vs TEST)
| tier | train | test | gap |
|---|---|---|---|
| T1 easy(1b) | 0.958 | 0.896 | +0.062 |
| T2 med(2b) | 0.583 | 0.500 | +0.083 |
| T3 hard(3b) | 0.375 | 0.438 | -0.062 |
| T4 expert(4b) | 0.292 | 0.125 | +0.167 |

## 5. Recurrence-Depth Ablation (T3-T4)
| T steps | Sys1 greedy |
|---|---|
| 1 | 0.271 |
| 2 | 0.333 |
| 4 | 0.292 |
| 8 | 0.188 |
| 12 | 0.146 |

## 6. Featured Gameplay Videos
* Rendered: `['runs\\soko_v2\\play_sys1_pass1.gif', 'runs\\soko_v2\\play_sys1_pass1_storyboard.png', 'runs\\soko_v2\\play_sys2.gif', 'runs\\soko_v2\\play_sys2_storyboard.png']`