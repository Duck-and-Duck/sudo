# Sudoku-AGI report  (v3.0.0)

* device `cuda` · params **74,732** · iterations **14** · wall **4.8 min** · peak GPU **405 MiB** · peak host RSS **0 MiB**

## 1. Acceptance gate

**FAIL** — `pass_at_2` >= 0.95 on tiers <= 2: measured **0.0208**

## 2. Proof suite (P1-P14)

| id | claim | status | measurement |
|---|---|---|---|
| P4 | constraint graph + 5 relation types | **PASS** | 20 peers/cell, REL symmetric, type counts=[81, 972, 324, 324, 4860] |
| P1 | verifier soundness + completeness | **PASS** | 212/212 value-changing swaps rejected; 2 independent verifiers agree |
| P2 | solver == independent reference | **PASS** | 17 boards, bitmask+MRV vs naive set solver, identical counts |
| P3 | generator: unique + valid + deterministic | **PASS** | 10 puzzles UNIQUE; seed replay identical; tiers=[3, 5, 0, 1, 1]; 1.0s |
| P10 | information accounting | **PASS** | log2(#grids)=72.50 bits/grid; |G|=1,218,998,108,160; Burnside orbits=5,472,730,538 |
| P5 | exact G-equivariance of the network | **PASS** | max|f(gx)-g f(x)| logits=3.13e-07 cand=5.36e-07 value=2.98e-08 (8 random g in G) |
| P6 | P(illegal action) == 0 exactly | **PASS** | 38 env steps: illegal mass=0, illegal picks=0; torch mask == numpy mask |
| P7 | numerical range certificate | **PASS** | all finite on empty/full/degenerate boards, T=16; max|logit|=0.580 <= bound 14.056 |
| P8 | Muon trust region (spectral) | **PASS** | certified sup=1.2048; measured sigma_max<=1.2022; sigma_min(cond<=100)=0.682 |
| P11 | potential shaping is policy-invariant | **PASS** | max|sum_t F_t - (81-filled0)/81| = 5.96e-08 over 6 episodes |
| P12 | pass@k estimator unbiased | **PASS** | max |MC - exact| = 0.0112 |
| P13 | RLOO baseline is exactly unbiased | **PASS** | enumerated 125 groups: |E[grad_LOO]-gradJ|=5.96e-08 |
| P9 | resource accounting (toy net) | **PASS** | toy P=33,964 => 0.13 MiB weights; Muon uses 1 buffer vs Adam's 2 |
| P14 | no train/test leakage | **PASS** | 0/120 test solution grids appear in train |

## 3. Held-out results (disjoint solution grids)

| tier | n | clues | Sys1 greedy | pass@1 | pass@2 | Sys1+2 (`simulate`) | avg sims | digit-ECE | dead-end |
|---|---|---|---|---|---|---|---|---|---|
| T1 easy | 12 | 40.8 | 0.833 | 0.021 | 0.042 | **0.000** | 16.0 | 0.125 | 0.167 |
| T2 medium | 12 | 29.9 | 0.333 | 0.000 | 0.000 | **0.000** | 16.0 | 0.113 | 0.667 |
| T3 hard | 3 | 32.7 | 0.000 | 0.000 | 0.000 | **0.000** | 16.0 | 0.123 | 1.000 |
| T4 expert | 4 | 24.5 | 0.000 | 0.000 | 0.000 | **0.000** | 16.0 | 0.249 | 1.000 |
| T5 extreme | 5 | 27.0 | 0.000 | 0.000 | 0.000 | **0.000** | 16.0 | 0.229 | 1.000 |

## 4. Comparison vs. Global Meta Models

| Model | Params | Data / Aug | Legality | Hard / Extreme Score |
|---|---|---|---|---|
| Frontier LLMs (R1 / o3-mini / Claude 3.7) | 100B-1T+ | 1x + CoT | Unchecked | 0.0% (Sudoku-Extreme) |
| Direct Transformer (arXiv:2510.04871) | 27M | 1,000x aug | Unchecked | 0.0% (Sudoku-Extreme) |
| Sapient HRM (arXiv:2506.21734) | 27M | Heavy aug | Unchecked | 55.0% (Sudoku-Extreme) |
| Samsung TRM-Att (arXiv:2510.04871) | 7M | 1,000x aug | Unchecked | 74.7% (Sudoku-Extreme) |
| Samsung TRM-MLP (arXiv:2510.04871) | 5M | 1,000x aug (~36h L40S) | Unchecked | 87.4% (Sudoku-Extreme) |
| Probabilistic TRM (PTRM, 2026) | 7M | Noise + Q-voting | Unchecked | 98.75% (Sudoku-Extreme) |
| **Sudoku-AGI v3.0.0 (Sys1 / Sys1+2)** | **74,732** | **1x (exact G-equivariant)** | **0% illegal (P6)** | **0.0% Sys1 / 0.0% Sys1+2 (T3-T5)** |

### Memorisation control (TRAIN vs TEST)

| tier | train greedy | test greedy | gap |
|---|---|---|
| T1 easy | 0.917 | 0.833 | +0.083 |
| T2 medium | 0.167 | 0.333 | -0.167 |
| T3 hard | 0.000 | 0.000 | +0.000 |
| T4 expert | 0.000 | 0.000 | +0.000 |
| T5 extreme | 0.000 | 0.000 | +0.000 |

## 6. Monomer -> module traceability

| monomer | implemented by | verified by |
|---|---|---|
| encode | features(): 15 G-covariant channels + tied Win | P5 |
| compare | per-digit attn q·k/√d + peer bias; CE/move_nll | P5,P7 |
| bind | key-value attention binds digit<->cell<->unit roles | P5 |
| store | weights + EMA + tabu visited set in System 2 | P9,P14 |
| retrieve | softmax attention over 81 cells per digit | P5 |
| predict | digit head + cand head + value head + conf head | P1,P2 |
| update | Muon spectral step + AdamW + fp16 scaler | P8 |
| value | value head P(solve|state) ranks System-2 branches | value_ece |
| select | masked softmax / argmax over 729 legal actions | P6 |
| gate | hard mask + block gate + in_gate + conf head gate | P6 |
| hold | input-anchored belief-feedback (y_t, z_t) stream | P7,sweep |
| sequence | autoregressive MDP + System-2 DFS backtracking | P11 |
| chunk | digit-axis & cell-axis invariant pools | P5 |
| map | tied row<->col weights + 5 relation types | P5 |
| uncertainty | conf-head + top-1 prob trigger for System 2 | P12,digit_ece |
| broadcast | shared residual stream + belief feedback y_proj | P5 |
| simulate | System 2 mental branch rollouts scored by value | sys2_pass |
| monitor | contradiction detection + backtracking repair | sys2_pass |