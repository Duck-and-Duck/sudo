# Sudoku-AGI report  (v5.0.1)

* device `cuda` | params **93,220** | iterations **44** | wall **3.5 min** | peak GPU **812 MiB** | peak host RSS **0 MiB**

## 1. Acceptance gate

**FAIL** - `pass_at_2` >= 0.95 on tiers <= 2: measured **0.7986**

## 2. Proof suite (P1-P14)

| id | claim | status | measurement |
|---|---|---|---|
| P4 | constraint graph + 5 relation types | **PASS** | 20 peers/cell, REL symmetric, type counts=[81, 972, 324, 324, 4860] |
| P1 | verifier soundness + completeness | **PASS** | 212/212 value-changing swaps rejected; 2 independent verifiers agree |
| P2 | solver == independent reference | **PASS** | 17 boards, bitmask+MRV vs naive set solver, identical counts |
| P3 | generator: unique + valid + deterministic | **PASS** | 10 puzzles UNIQUE; seed replay identical; tiers=[3, 5, 0, 1, 1]; 0.2s |
| P10 | information accounting | **PASS** | log2(#grids)=72.50 bits/grid; |G|=1,218,998,108,160; Burnside orbits=5,472,730,538 |
| P5 | exact G-equivariance of HyperGraphNet | **PASS** | max|f(gx)-g f(x)| logits=3.28e-07 cand=3.58e-07 value=4.47e-08 (8 random g in G) |
| P6 | P(illegal action) == 0 exactly | **PASS** | 34 env steps: illegal mass=0, illegal picks=0; torch mask == numpy mask |
| P7 | numerical range certificate | **PASS** | all finite on empty/full/degenerate boards, T=16; max|logit|=0.646 <= bound 17.740 |
| P8 | Muon trust region (spectral) | **PASS** | certified sup=1.2048; measured sigma_max<=1.2022; sigma_min(cond<=100)=0.682 |
| P11 | potential shaping is policy-invariant | **PASS** | max|sum_t F_t - (81-filled0)/81| = 0.00e+00 over 6 episodes |
| P12 | pass@k estimator unbiased | **PASS** | max |MC - exact| = 0.0112 |
| P13 | RLOO baseline is exactly unbiased | **PASS** | enumerated 125 groups: |E[grad_LOO]-gradJ|=5.96e-08 |
| P9 | resource accounting (toy net) | **PASS** | toy P=42,180 => 0.16 MiB weights; Muon uses 1 buffer vs Adam's 2 |
| P14 | no train/test leakage | **PASS** | 0/120 test solution grids appear in train |

## 3. Held-out results (disjoint solution grids)

| tier | n | clues | Sys1 greedy | pass@1 | pass@2 | Sys1+2 (`simulate`) | avg sims | digit-ECE | dead-end |
|---|---|---|---|---|---|---|---|---|---|
| T1 easy | 12 | 40.8 | 1.000 | 0.958 | 0.986 | **1.000** | 0.0 | 0.001 | 0.000 |
| T2 medium | 12 | 29.9 | 0.750 | 0.479 | 0.611 | **1.000** | 0.7 | 0.102 | 0.250 |
| T3 hard | 3 | 32.7 | 0.667 | 0.583 | 0.889 | **1.000** | 0.0 | 0.169 | 0.333 |
| T4 expert | 4 | 24.5 | 0.500 | 0.188 | 0.375 | **0.750** | 8.0 | 0.224 | 0.500 |
| T5 extreme | 5 | 27.0 | 0.600 | 0.100 | 0.200 | **0.800** | 5.8 | 0.161 | 0.400 |

## 4. Comparison vs. Global Meta Models

| Model | Params | Data / Aug | Legality | Hard / Extreme Score |
|---|---|---|---|---|
| Frontier LLMs (R1 / o3-mini / Claude 3.7) | 100B-1T+ | 1x + CoT | Unchecked | 0.0% (Sudoku-Extreme) |
| Direct Transformer (arXiv:2510.04871) | 27M | 1,000x aug | Unchecked | 0.0% (Sudoku-Extreme) |
| Sapient HRM (arXiv:2506.21734) | 27M | Heavy aug | Unchecked | 55.0% (Sudoku-Extreme) |
| Samsung TRM-Att (arXiv:2510.04871) | 7M | 1,000x aug | Unchecked | 74.7% (Sudoku-Extreme) |
| Samsung TRM-MLP (arXiv:2510.04871) | 5M | 1,000x aug (~36h L40S) | Unchecked | 87.4% (Sudoku-Extreme) |
| Probabilistic TRM (PTRM, 2026) | 7M | Noise + Q-voting | Unchecked | 98.75% (Sudoku-Extreme) |
| **Sudoku-AGI v5.0.1 (Sys1 / Sys1+2)** | **93,220** | **1x (exact G-equivariant)** | **0% illegal (P6)** | **58.3% Sys1 / 83.3% Sys1+2 (T3-T5, n=12)** |

### Memorisation control (TRAIN vs TEST)

| tier | train greedy | test greedy | gap |
|---|---|---|
| T1 easy | 1.000 | 1.000 | +0.000 |
| T2 medium | 0.750 | 0.750 | +0.000 |
| T3 hard | 0.500 | 0.667 | -0.167 |
| T4 expert | 0.500 | 0.500 | +0.000 |
| T5 extreme | 0.167 | 0.600 | -0.433 |

## 6. Monomer -> module traceability

| monomer | implemented by | verified by |
|---|---|---|
| encode | TaskAdapter -> domain-agnostic (B,N,K,F) + tied Win | P5 |
| compare | HyperGraphBlock: arbitrary hyperedge sets + slot attn | P5,P7 |
| bind | key-value attention binds entity<->slot<->hyperedge | P5 |
| store | weights + EMA + DFS tabu visited set in System 2 | P9,P14 |
| retrieve | hypergraph softmax attention over relational units | P5 |
| predict | action head + cand head + value head + conf head | P1,P2 |
| update | Muon spectral step + AdamW + fp16 dynamic scaler | P8 |
| value | value head P(solve|state) ranks System-2 branches | value_ece |
| select | masked softmax / argmax over N*K legal actions | P6 |
| gate | hard legality mask + contractive step_gate + conf | P6 |
| hold | contractive segmented belief-feedback (y_t, z_t) | P7,sweep |
| sequence | autoregressive MDP + uncertainty-recorded DFS | P11 |
| chunk | hyperedge pools (any degree/size, Sokoban-ready) | P5 |
| map | tied hyperedge weights + tied features => G-equiv | P5 |
| uncertainty | top-1 prob trigger for System 2 DFS + digit-ECE | P12,digit_ece |
| broadcast | shared residual stream + belief feedback y_proj | P5 |
| simulate | System 2 full-depth neural DFS rollouts | sys2_pass |
| monitor | contradiction detection + lowest-conf backtracking | sys2_pass |