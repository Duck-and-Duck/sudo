# Sokoban-AGI report (v1.0.2)

* device `cuda` | grid `8x8` | params **92,692** | iters **139** | peak GPU **760 MiB**

## 1. Proof Suite (P1-P14)

| id | claim | status | measurement |
|---|---|---|---|
| P4 | D4 hypergraph topology (row/col/3x3) | **PASS** | 8x8=64 cells, row/col=(8,8), patch=(64,9) |
| P1 | verifier soundness + box conservation | **PASS** | 6 optimal trajectories verified end-to-end |
| P3 | generator: solvable + deterministic | **PASS** | all levels BFS-verified solvable; seed replay identical |
| P2 | BFS+pruning == unpruned reference | **PASS** | 5 levels exact shortest-path match |
| P10 | information & D4 symmetry accounting | **PASS** | |D4|=8 dihedral symmetries; walkable~36 cells => C(36,4)*36 > 1e6 states/map |
| P5 | exact D4 equivariance (all 8 symms) | **PASS** | max|f(gx)-g f(x)| logits=6.11e-07 value=5.96e-08 |
| P6 | P(illegal move) == 0 exactly | **PASS** | 30 env steps: 0 wall/box-jam illegal picks |
| P7 | numerical range certificate (T=16) | **PASS** | all finite; max|logit|=0.443 <= bound 20.337 |
| P8 | Muon trust region (spectral) | **PASS** | cert=1.2048; sigma_max=1.2022; sigma_min=0.682 |
| P11 | potential shaping is policy-invariant | **PASS** | max|sum_t F_t - (-Phi(s0))| = 0.00e+00 |
| P12 | pass@k estimator unbiased | **PASS** | exact hypergeometric 1 - C(n-c,k)/C(n,k) |
| P13 | RLOO baseline unbiased | **PASS** | G/(G-1) leave-one-out unbiasedness inherited from core |
| P9 | resource accounting (toy net) | **PASS** | toy P=41,828 => 0.16 MiB weights |
| P14 | no D4-orbit train/test leakage | **PASS** | 0/64 test levels overlap train D4 orbits |

## 2. Held-Out Sokoban Results (disjoint D4-canonical levels)

| tier | n | opt_steps | Sys1 greedy | pass@1 | pass@2 | Sys1+2 (`simulate`) | avg nodes |
|---|---|---|---|---|---|---|---|
| T1 easy(1b) | 16 | 5.4 | 1.000 | 0.953 | 1.000 | **1.000** | 0.0 |
| T2 med(2b) | 16 | 8.2 | 0.625 | 0.656 | 0.792 | **1.000** | 6.9 |
| T3 hard(3b) | 16 | 11.1 | 0.438 | 0.578 | 0.667 | **0.938** | 18.4 |
| T4 expert(4b) | 16 | 13.1 | 0.312 | 0.375 | 0.458 | **0.688** | 29.2 |

## 3. Featured Gameplay Video
* Rendered: `['runs\\soko_smoke\\play_best.gif']`