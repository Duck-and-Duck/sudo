# Sudoku-AGI report  (v4.0.3)

* device `cuda` | params **532,996** | iterations **275** | wall **33.6 min** | peak GPU **2022 MiB** | peak host RSS **0 MiB**

## 1. Acceptance gate

**FAIL** — `pass_at_2` >= 0.95 on tiers <= 2: measured **0.9115**

## 2. Proof suite (P1-P14)

| id | claim | status | measurement |
|---|---|---|---|
| P4 | constraint graph + 5 relation types | **PASS** | 20 peers/cell, REL symmetric, type counts=[81, 972, 324, 324, 4860] |
| P1 | verifier soundness + completeness | **PASS** | 212/212 value-changing swaps rejected; 2 independent verifiers agree |
| P2 | solver == independent reference | **PASS** | 17 boards, bitmask+MRV vs naive set solver, identical counts |
| P3 | generator: unique + valid + deterministic | **PASS** | 24 puzzles UNIQUE; seed replay identical; tiers=[9, 12, 1, 1, 1]; 0.3s |
| P10 | information accounting | **PASS** | log2(#grids)=72.50 bits/grid; |G|=1,218,998,108,160; Burnside orbits=5,472,730,538 |
| P5 | exact G-equivariance of the network | **PASS** | max|f(gx)-g f(x)| logits=2.98e-07 cand=3.58e-07 value=5.96e-08 (8 random g in G) |
| P6 | P(illegal action) == 0 exactly | **PASS** | 35 env steps: illegal mass=0, illegal picks=0; torch mask == numpy mask |
| P7 | numerical range certificate | **PASS** | all finite on empty/full/degenerate boards, T=16; max|logit|=0.477 <= bound 17.740 |
| P8 | Muon trust region (spectral) | **PASS** | certified sup=1.2048; measured sigma_max<=1.2022; sigma_min(cond<=100)=0.682 |
| P11 | potential shaping is policy-invariant | **PASS** | max|sum_t F_t - (81-filled0)/81| = 0.00e+00 over 6 episodes |
| P12 | pass@k estimator unbiased | **PASS** | max |MC - exact| = 0.0132 |
| P13 | RLOO baseline is exactly unbiased | **PASS** | enumerated 125 groups: |E[grad_LOO]-gradJ|=5.96e-08 |
| P9 | resource accounting (toy net) | **PASS** | toy P=41,924 => 0.16 MiB weights; Muon uses 1 buffer vs Adam's 2 |
| P14 | no train/test leakage | **PASS** | 0/800 test solution grids appear in train |

## 3. Held-out results (disjoint solution grids)

| tier | n | clues | Sys1 greedy | pass@1 | pass@2 | Sys1+2 (`simulate`) | avg sims | digit-ECE | dead-end |
|---|---|---|---|---|---|---|---|---|---|
| T1 easy | 48 | 40.7 | 1.000 | 0.979 | 0.997 | **1.000** | 0.0 | 0.000 | 0.000 |
| T2 medium | 48 | 30.3 | 0.917 | 0.714 | 0.826 | **1.000** | 0.1 | 0.029 | 0.083 |
| T3 hard | 27 | 29.6 | 0.741 | 0.407 | 0.599 | **1.000** | 1.7 | 0.074 | 0.259 |
| T4 expert | 47 | 26.4 | 0.617 | 0.378 | 0.592 | **1.000** | 3.9 | 0.140 | 0.383 |
| T5 extreme | 35 | 25.4 | 0.657 | 0.300 | 0.481 | **1.000** | 1.0 | 0.095 | 0.343 |

## 4. Comparison vs. Global Meta Models

| Model | Params | Data / Aug | Legality | Hard / Extreme Score |
|---|---|---|---|---|
| Frontier LLMs (R1 / o3-mini / Claude 3.7) | 100B-1T+ | 1x + CoT | Unchecked | 0.0% (Sudoku-Extreme) |
| Direct Transformer (arXiv:2510.04871) | 27M | 1,000x aug | Unchecked | 0.0% (Sudoku-Extreme) |
| Sapient HRM (arXiv:2506.21734) | 27M | Heavy aug | Unchecked | 55.0% (Sudoku-Extreme) |
| Samsung TRM-Att (arXiv:2510.04871) | 7M | 1,000x aug | Unchecked | 74.7% (Sudoku-Extreme) |
| Samsung TRM-MLP (arXiv:2510.04871) | 5M | 1,000x aug (~36h L40S) | Unchecked | 87.4% (Sudoku-Extreme) |
| Probabilistic TRM (PTRM, 2026) | 7M | Noise + Q-voting | Unchecked | 98.75% (Sudoku-Extreme) |
| **Sudoku-AGI v4.0.3 (Sys1 / Sys1+2)** | **532,996** | **1x (exact G-equivariant)** | **0% illegal (P6)** | **67.2% Sys1 / 100.0% Sys1+2 (T3-T5)** |

### Memorisation control (TRAIN vs TEST)

| tier | train greedy | test greedy | gap |
|---|---|---|
| T1 easy | 1.000 | 1.000 | +0.000 |
| T2 medium | 1.000 | 0.917 | +0.083 |
| T3 hard | 0.792 | 0.741 | +0.051 |
| T4 expert | 0.667 | 0.617 | +0.050 |
| T5 extreme | 0.667 | 0.657 | +0.010 |

## 5. Recurrence-depth ablation (TC0 argument)

| T steps | easy/med (T<=2) | hard/extreme (T>=3) |
|---|---|---|
| 1 | 0.875 | 0.292 |
| 2 | 0.854 | 0.500 |
| 4 | 0.958 | 0.722 |
| 8 | 0.938 | 0.694 |
| 12 | 0.938 | 0.625 |
| 16 | 0.917 | 0.611 |

## 6. Monomer -> module traceability

| monomer | implemented by | verified by |
|---|---|---|
| encode | features(): 15 G-covariant channels + tied Win | P5 |
| compare | UnitBlock: tied Row/Col + Box + Cross-Digit attn | P5,P7 |
| bind | key-value attention binds digit<->cell<->unit roles | P5 |
| store | weights + EMA + DFS tabu visited set in System 2 | P9,P14 |
| retrieve | unit-factorized softmax attention over peers & digits | P5 |
| predict | digit head + cand head + value head + conf head | P1,P2 |
| update | Muon spectral step + AdamW + fp16 dynamic scaler | P8 |
| value | value head P(solve|state) ranks System-2 branches | value_ece |
| select | masked softmax / argmax over 729 legal actions | P6 |
| gate | hard legality mask + in_gate + uncertainty trigger | P6 |
| hold | segmented belief-feedback (y_t, z_t) stream | P7,sweep |
| sequence | autoregressive MDP + uncertainty-recorded DFS | P11 |
| chunk | row / col / box / digit unit pools | P5 |
| map | tied row<->col attn + tied features => G-equivariant | P5 |
| uncertainty | top-1 prob trigger for System 2 DFS + digit-ECE | P12,digit_ece |
| broadcast | shared residual stream + belief feedback y_proj | P5 |
| simulate | System 2 full-depth neural DFS rollouts | sys2_pass |
| monitor | contradiction detection + lowest-conf backtracking | sys2_pass |